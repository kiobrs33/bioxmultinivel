<a href="{{route('partner.partners.show', $slugSocio)}}" class="btn bg-gradient-success btn-xs">
    <i class="fas fa-eye"></i>
</a>