@extends('orders.index')

@section('contenido')
TABLA ORDENES
@endsection