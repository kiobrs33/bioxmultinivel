<button type="button" class="btn btn-success btn-xs btn-addProducto">
    <i class="fas fa-plus"></i>
</button>