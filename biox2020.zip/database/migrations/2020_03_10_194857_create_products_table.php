<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->string('codigoProducto');
            $table->string('nombreProducto');
            $table->text('descripcionProducto');
            $table->double('precioProducto');
            $table->integer('puntosProducto');
            $table->enum('tipoUnidadProducto', ['unidad','kilogramo','litro']);
            $table->string('urlImagenProducto');
            $table->string('slugProducto');
            
            $table->integer('categories_id')->unsigned();
            $table->foreign('categories_id')->references('id')->on('categories');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}