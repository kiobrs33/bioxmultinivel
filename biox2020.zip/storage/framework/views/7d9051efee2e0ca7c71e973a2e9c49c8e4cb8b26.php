<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Razon Social</th>
                    <th>Ruc</th>
                    <th>Direccion</th>
                    <th>Telefono</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>