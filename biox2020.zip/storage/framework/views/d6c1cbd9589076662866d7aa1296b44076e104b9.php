<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscripcion Biox</title>
</head>
<body>
    <h4>Inscripcion Satisfactoria!</h4>
    Bienvenida(o) <?php echo e($credenciales['nombresSocio']); ?>


    <ul>
        <li>Tu codigo de usuario es : <?php echo e($credenciales['username']); ?></li>
        <li>Tu contraseña es : <?php echo e($credenciales['password']); ?></li>
    </ul>
    
    
</body>
</html>