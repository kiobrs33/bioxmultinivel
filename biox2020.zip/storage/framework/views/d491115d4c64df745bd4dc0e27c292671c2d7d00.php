<?php $__env->startSection('contenido-header'); ?>
<div class="content-header">
    <div class="container">
        <div class="row mb-2">

            <div class="col-auto">
                <!-- <a href="" class="btn btn-danger btn-sm btn-block"><i class="fas fa-arrow-left"></i> Atras</a> -->
                <h1>Informacion de la Inscripcion</h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-3">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="text-center text-lightblue mb-4"><?php echo e($insDataSocio->usernameSocio); ?></h4>
                            <div class="text-center">
                                <img class=" profile-user-img img-fluid img-circle" src="/images/imagenVacia.png"
                                    alt="User profile picture">
                            </div>
                            <br>
                            <a href="<?php echo e(route('partner.inscriptions.index')); ?>"
                                class="btn bg-gradient-danger btn-xs btn-block">
                                <i class="fas fa-arrow-left"></i> Atras
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <h4 class="text-lightblue mb-4"><i class="fas fa-user-alt"></i> Informacion personal</h4>
                            <div class="row">
                                <div class="col-sm-6 invoice-col">
                                    <b>Nombres :</b> <?php echo e($insDataSocio->nombresSocio); ?><br>
                                    <b>Apellido Paterno :</b> <?php echo e($insDataSocio->apellidoPaternoSocio); ?><br>
                                    <b>Apellido Materno :</b> <?php echo e($insDataSocio->apellidoMaternoSocio); ?>

                                </div>
                                <div class="col-sm-6 invoice-col">
                                    <b>Fecha nacimiento :</b> <?php echo e($insDataSocio->fechaNacimientoSocio); ?><br>
                                    <b>Sexo :</b> <?php echo e($insDataSocio->sexoSocio); ?><br>
                                    <b>Dni :</b> <?php echo e($insDataSocio->dniSocio); ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-6 invoice-col">
                                    <b>Direccion :</b> <?php echo e($insDataSocio->direccionSocio); ?><br>
                                    <b>Pais :</b> <?php echo e($insDataSocio->paisSocio); ?>

                                </div>
                                <div class="col-sm-6 invoice-col">
                                    <b>Departamento :</b> <?php echo e($insDataSocio->departamentoSocio); ?><br>
                                    <b>Provincia :</b> <?php echo e($insDataSocio->provinciaSocio); ?><br>
                                    <b>Distrito :</b> <?php echo e($insDataSocio->distritoSocio); ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-6 invoice-col">
                                    <b>Correo :</b> <?php echo e($insDataSocio->correoSocio); ?><br>
                                    <b>Telefono :</b> <?php echo e($insDataSocio->telefonoSocio); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-end">
        <div class="col-sm-9">
            <div class="card">
                <div class="card-body">
                    <h4 class="text-lightblue mb-4"><i class=" fas fa-briefcase"></i> Detalles de la
                        inscripcion</h4>
                    <div class="row">
                        <div class="col-sm-6 invoice-col">
                            <b>Fecha de Inscripcion :</b> <?php echo e($insDataSocio->fechaInscripcion); ?><br>
                        </div>
                        <div class="col-sm-6 invoice-col">
                            <b>Paquete :</b> <?php echo e(($insPaquete) ? $insPaquete->nombrePaquete : 'No tiene'); ?><br>
                        </div>
                    </div>
                    <br>
                    <?php if($insDetallesOrden): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th>Codigo #</th>
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
                                    <th>Puntos</th>
                                    <th style="width:16%">Subtotal S/.</th>
                                    <th style="width:16%">Subtotal puntos</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $insDetallesOrden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ins->codigoProducto); ?></td>
                                    <td><?php echo e($ins->nombreProducto); ?></td>
                                    <td><?php echo e($ins->cantidadDetallePedido); ?></td>
                                    <td>S/<?php echo e($ins->precioDetallePedido); ?></td>
                                    <td><?php echo e($ins->puntosDetallePedido); ?></td>
                                    <td>S/<?php echo e($ins->subtotalPrecioDetallePedido); ?></td>
                                    <td><?php echo e($ins->subtotalPuntosDetallePedido); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                        </div>
                        <div class="col-sm-6">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <tr>
                                        <th style="width:50%">Subtotal:</th>
                                        <td>S/<?php echo e($insLibre->subtotalPedido); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Impuesto (1.3%)</th>
                                        <td>S/<?php echo e($insLibre->impuestoPedido); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Total:</th>
                                        <td>$/<?php echo e($insLibre->totalPedido); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Total Puntos:</th>
                                        <td><?php echo e($insLibre->puntosTotalPedido); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appPartner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>