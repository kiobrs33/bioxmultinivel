<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-12 col-md-10 col-lg-7">

            <div class="card card-secondary mt-3">
                <div class="card-header">
                    Nuevo Trabajador
                </div>

                <form action="<?php echo e(route('admin.employees.update')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <input type="hidden" value="<?php echo e($trabajador->id); ?>" name="id_trabajador">
                    <input type="hidden" value="<?php echo e($trabajador->users_id); ?>" name="id_usuario">

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>
                                        <button type="button" class="btn btn-success btn-xs"
                                            id="btn_buscar_dnitTrabajador">
                                            <i class="fas fa-search"></i> BUSCAR DATOS POR DNI
                                        </button>
                                    </label>
                                    <input type="number"
                                        class="form-control form-control-sm inputCentrado<?php echo e($errors->has('dni') ? ' is-invalid' : ''); ?>"
                                        value="<?php echo e($trabajador->dniTrabajador); ?>" id="dni_trabajador" name="dni">
                                    <?php echo $errors->first('dni','<span class="error invalid-feedback">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>Nombres</label>
                                    <input type="text"
                                        class="form-control form-control-sm inputCentrado<?php echo e($errors->has('nombres') ? ' is-invalid' : ''); ?>"
                                        value="<?php echo e($trabajador->nombresTrabajador); ?>" id="nombres_trabajador"
                                        name="nombres">
                                    <?php echo $errors->first('nombres','<span
                                        class="error invalid-feedback">:message</span>'); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>Apellido Paterno</label>
                                    <input type="text"
                                        class="form-control form-control-sm inputCentrado<?php echo e($errors->has('apellido_paterno') ? ' is-invalid' : ''); ?>"
                                        value="<?php echo e($trabajador->apellidoPaternoTrabajador); ?>"
                                        id="apellido_paterno_trabajador" name="apellido_paterno">
                                    <?php echo $errors->first('apellido_paterno','<span
                                        class="error invalid-feedback">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>Apellido Materno</label>
                                    <input type="text"
                                        class="form-control form-control-sm inputCentrado<?php echo e($errors->has('apellido_materno') ? ' is-invalid' : ''); ?>"
                                        value="<?php echo e($trabajador->apellidoMaternoTrabajador); ?>"
                                        id="apellido_materno_trabajador" name="apellido_materno">
                                    <?php echo $errors->first('apellido_materno','<span
                                        class="error invalid-feedback">:message</span>'); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>Telefono</label>
                                    <input type="text"
                                        class="form-control form-control-sm inputCentrado<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>"
                                        value="<?php echo e($trabajador->telefonoTrabajador); ?>" name="telefono">
                                    <?php echo $errors->first('telefono','<span
                                        class="error invalid-feedback">:message</span>'); ?>

                                </div>

                            </div>
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>Sexo</label>
                                    <select
                                        class="form-control form-control-sm<?php echo e($errors->has('sexo') ? ' is-invalid' : ''); ?>"
                                        name="sexo">
                                        <?php if($trabajador->sexoTrabajador == 'masculino'): ?>
                                        <option value="masculino" selected>Masculino</option>
                                        <option value="femenino">Femenino</option>
                                        <?php else: ?>
                                        <option value="masculino">Masculino</option>
                                        <option value="femenino" selected>Femenino</option>
                                        <?php endif; ?>
                                    </select>
                                    <?php echo $errors->first('sexo','<span class="error invalid-feedback">:message</span>'); ?>

                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Direccion de domicilio</label>
                            <input type="text"
                                class="form-control form-control-sm inputCentrado<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>"
                                value="<?php echo e($trabajador->direccionTrabajador); ?>" name="direccion">
                            <?php echo $errors->first('direccion','<span class="error invalid-feedback">:message</span>'); ?>

                        </div>

                        <div class="form-group">
                            <label>Correo</label>
                            <input type="email"
                                class="form-control form-control-sm inputCentrado<?php echo e($errors->has('correo') ? ' is-invalid' : ''); ?>"
                                value="<?php echo e($trabajador->correoTrabajador); ?>" name="correo">
                            <?php echo $errors->first('correo','<span class="error invalid-feedback">:message</span>'); ?>

                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="container-fluid">
                            <div class="row justify-content-between">
                                <div class="col-5 col-sm-5 col-md-5 col-lg-4">
                                    <button type="submit" class="btn btn-primary btn-block btn-sm">
                                        <i class="fas fa-save"></i> Guardar
                                    </button>
                                </div>
                                <div class="col-5 col-sm-5 col-md-5 col-lg-4">
                                    <a href="<?php echo e(route('admin.employees.index')); ?>"
                                        class="btn btn-danger btn-block btn-sm">
                                        <i class="fas fa-undo-alt"></i> Atras
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>