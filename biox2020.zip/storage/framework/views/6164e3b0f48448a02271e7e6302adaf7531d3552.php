<a href="<?php echo e(route('partner.partners.show', $slugSocio)); ?>" class="btn bg-gradient-success btn-xs">
    <i class="fas fa-eye"></i>
</a>