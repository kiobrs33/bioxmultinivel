<?php $__env->startSection('contenido-header'); ?>
<div class="content-header">
    <div class="container">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h1>Bonos</h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-3">
            <div class="card">
                <div class="card-body p-0">
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item">
                            <a href="<?php echo e(route('partner.inscriptions.index')); ?>"
                                class="nav-link<?php echo e(request()->is('partner/inscriptions') ? ' active' : ''); ?>">
                                <i class="fas fa-list-ul"></i> Bono Paquete
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link<?php echo e(request()->is('partner/partners') ? ' active' : ''); ?>">
                                <i class="fas fa-users"></i> Bono Rango
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href=""
                                class="nav-link<?php echo e(request()->is('partner/partners/tree-partners/*') ? ' active' : ''); ?>">
                                <i class="fas fa-sitemap"></i> Bono Mercadeo
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
        <div class="col-lg-9">
            <?php echo $__env->yieldContent('contenidoBono'); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appPartner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>