<?php $__env->startSection('contenidoInscription'); ?>
<div class="callout callout-info">
    <h5><i class="fas fa-door-open"></i> Bienvenido al visor de arbol uninivel!</h5>
</div>
<div class="card">
    <div class="card-body">

        <?php $__currentLoopData = $misSocios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position=>$valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- ACCIENDO A LA INFORMACION DEL LIDER -->
        <?php if($position == 0): ?>
        <!-- Con esta condicion controlamos cuando el USARIO MOSTRADO EN EL ARBOL ES EL LOGUEADO  -->
        <!-- En el caso no lo sea APARECERA UN BOTON para subir de nivel en el arbol -->
        <!-- ISSET nos permite saber si una VARIABLE ESTA DEFINIDA Y NO ES NULL -->
        <?php if(!isset($misSocios[0][0]->slug_lider)): ?>
        <div class="row justify-content-center">
            <div class="col-auto">
                <div class="card" style="border-radius:10px; background: radial-gradient(white,#75D81B)">
                    <div class="card-body">
                        <h6 class="text-center text-sm">Codigo :
                            <b><?php echo e($misSocios[0][0]->username); ?></b>
                        </h6>
                        <div class="row justify-content-center">
                            <div class="col-auto">
                                <img class="profile-user-img img-fluid img-circle img-md" src="/images/imagenVacia.png"
                                    alt="User profile picture">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 align="center" class="text-sm">
                                    <?php echo e($misSocios[0][0]->nombresSocio.' '.$misSocios[0][0]->apellidoPaternoSocio.' '.$misSocios[0][0]->apellidoMaternoSocio); ?>

                                </h6>
                            </div>
                        </div>
                        <h6 class="text-center text-sm"><b><i class="fas fa-crown"></i> Lider <i
                                    class="fas fa-crown"></i></b></h6>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="row justify-content-center">
            <div class="col-auto">
                <div class="card" style="border-radius:10px; background: radial-gradient(white,#FF870F)">
                    <div class="card-body">
                        <h6 align="center" class="text-sm mt-1">Codigo :
                            <b><?php echo e($misSocios[0][0]->username); ?></b>
                        </h6>
                        <div class="row justify-content-center">
                            <div class="col-auto">
                                <img class="profile-user-img img-fluid img-circle img-md" src="/images/imagenVacia.png"
                                    alt="User profile picture">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 align="center" class="text-sm">
                                    <?php echo e($misSocios[0][0]->nombresSocio.' '.$misSocios[0][0]->apellidoPaternoSocio.' '.$misSocios[0][0]->apellidoMaternoSocio); ?>

                                </h6>
                            </div>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-12">
                                <a href="<?php echo e(route('partner.partners.tree-partners',$misSocios[0][0]->slug_lider)); ?>"
                                    class="btn btn-info btn-xs btn-block" style="border-radius:10px;">
                                    <i class="fas fa-arrow-up"></i> Subir
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php else: ?>
        <div style="display:flex; overflow-x:auto;">
            <!-- ENLISTADO LOS SOCIOS DIRECTOS -->
            <?php $__currentLoopData = $misSocios[$position]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="min-width:130px; margin:5px;">
                <div class="card" style="border-radius:10px; background: radial-gradient(white,#17A2B8)">
                    <div class="card-body">
                        <h6 align="center" class="text-sm"><b><?php echo e($item->username); ?></b></h6>
                        <div class="row justify-content-center">
                            <div class="col-auto">
                                <img class="profile-user-img img-fluid img-circle img-md" src="/images/imagenVacia.png"
                                    alt="User profile picture">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <h6 align="center" class="text-xs">
                                    <?php echo e($item->nombresSocio); ?>

                                </h6>
                            </div>
                        </div>

                        <div class="row justify-content-center">
                            <div class="col-12">
                                <a href="<?php echo e(route('partner.partners.tree-partners',$item->slugSocio)); ?>"
                                    class="btn btn-success btn-xs btn-block" style="border-radius:10px;">
                                    <i class="fas fa-eye"></i> Ver Arbol
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<div class="card">
    <div class="card-body">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partnerviews.containerOrganization', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>