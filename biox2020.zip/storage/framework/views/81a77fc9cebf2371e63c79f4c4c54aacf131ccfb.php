<?php $__env->startSection('contenido-header'); ?>
<div class="content-header">
    <div class="container">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h1>Mi socio</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-4">
            <!-- Profile Image -->
            <div class="card card-info card-outline">
                <div class="card-body box-profile">
                    <div class="text-center">
                        <img class="profile-user-img img-fluid img-circle" src="/images/imagenVacia.png"
                            alt="User profile picture">
                    </div>

                    <h3 class="profile-username text-center">
                        <?php echo e($misocio->nombresSocio.' '.$misocio->apellidoPaternoSocio.' '.$misocio->apellidoMaternoSocio); ?>

                    </h3>

                    <p class="text-muted text-center">Socio desde <b><?php echo e($misocio->fechaInscripcion); ?></b></p>

                    <ul class="list-group list-group-unbordered mb-3">
                        <li class="list-group-item">
                            <b><i class="fas fa-users"></i> Socios Directos</b> <a class="float-right">0</a>
                        </li>
                        <li class="list-group-item">
                            <b><i class="fas fa-user-shield"></i> Codigo</b>
                            <a class="float-right"><?php echo e($misocio->username); ?></a>
                        </li>
                    </ul>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>

        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="informacion-contacto-tab" data-toggle="pill"
                                href="#informacion-general" role="tab" aria-controls="custom-content-below-home"
                                aria-selected="true">General</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="ordenes-socio-tab" data-toggle="pill" href="#ordenes-socio"
                                role="tab" aria-controls="custom-content-below-messages"
                                aria-selected="false">Ordenes</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="custom-content-below-tabContent">

                        <div class="tab-pane fade show active" id="informacion-general" role="tabpanel"
                            aria-labelledby="informacion-contacto-tab">
                            <div class="row">
                                <div class="col-lg-12 mt-4">
                                    <h6><b>Informacion de Contacto</b></h6>
                                    <ul>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-address-card"></i>
                                            Dni : <b><?php echo e($misocio->dniSocio); ?></b></li>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-phone"></i>
                                            Telefono : <b><?php echo e($misocio->telefonoSocio); ?></b></li>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-envelope"></i>
                                            Correo : <b><?php echo e($misocio->correo_electronico); ?></b>
                                        </li>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-user-shield"></i>
                                            Codigo : <b><?php echo e($misocio->username); ?></b>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h6><b>Colocacion</b></h6>
                                    <ul>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-user-tie"></i>
                                            Patrocinador :
                                            <b><?php echo e($misocio->nombres_lider.' '.$misocio->apellido_paterno_lider.' '.$misocio->apellido_materno_lider); ?></b>
                                        </li>
                                        <li class="li-sin-signo">
                                            <i class="far fa-calendar-alt"></i> Fecha Inscripcion :
                                            <b><?php echo e($misocio->fechaInscripcion); ?></b>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h6><b>Direcciones</b></h6>
                                    <ul>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-home"></i>
                                            <?php echo e($misocio->direccionSocio); ?>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h6><b>Acciones</b></h6>
                                    <ul>
                                        <li class="li-sin-signo">
                                            <a href="#"><i class="fas fa-sitemap"></i> Ver Gráfica de Línea
                                                Descendiente</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="ordenes-socio" role="tabpanel"
                            aria-labelledby="ordenes-socio-tab">
                            Aqui solo se podra ver los pedidos realizado del Socio Directo.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appPartner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>