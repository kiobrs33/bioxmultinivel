<?php $__env->startSection('contenido'); ?>
<div class="container-fluid">
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr style="background-color:#E8C6E8">
                    <th class="filasTable">ID</th>
                    <th class="filasTable">Fecha Registro</th>
                    <th class="filasTable">Total Venta</th>
                    <th class="filasTable">Subtotal Venta</th>
                    <th class="filasTable">Impuesto</th>
                    <th class="filasTable">Puntos</th>
                    <th width="100px">
                        <a href="<?php echo e(route('admin.inscriptions.create')); ?>" class="btn btn-success btn-block btn-sm"><i
                                class="fas fa-plus-circle"></i> Nuevo</a>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $inscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="filasTable"><?php echo e($insc->id); ?></td>
                    <td class="filasTable"><?php echo e($insc->fecha_registro); ?></td>
                    <td class="filasTable"><?php echo e($insc->total_venta); ?></td>
                    <td class="filasTable"><?php echo e($insc->subtotal_venta); ?></td>
                    <td class="filasTable"><?php echo e($insc->impuesto); ?></td>
                    <td class="filasTable"><?php echo e($insc->puntaje_total); ?></td>
                    <td align="center">
                        <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                            <a href="<?php echo e(route('admin.inscriptions.show', $insc->slug)); ?>" class="btn btn-info">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('admin.inscriptions.edit', $insc->slug)); ?>" class="btn btn-secondary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button type="button" class="btn btn-danger">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td>
                        <?php echo e($inscripciones->links("pagination::bootstrap-4")); ?>

                    </td>
                </tr>
            </tfoot>
        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>