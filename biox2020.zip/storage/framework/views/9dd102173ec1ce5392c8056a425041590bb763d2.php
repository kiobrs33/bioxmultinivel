<?php $__env->startSection('contenido-header'); ?>
<div class="content-header">
    <div class="container">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h1>Mis socios directos</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Socios Directos</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped table-sm">
                    <thead>
                        <tr>
                            <th></th>
                            <th class="filasTable">Codigo</th>
                            <th class="filasTable">Nombres</th>
                            <th class="filasTable">Apellidos</th>
                            <th class="filasTable">Dni</th>
                            <th class="filasTable">Departamento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sociosDirectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="filasTable">
                                <a href="<?php echo e(route('partner.inscriptions.show-my-partner', $socio->slugSocio)); ?>"
                                    class="btn btn-info btn-xs"><i class="far fa-eye"></i> Ver</a>
                            </td>
                            <td class="filasTable"><?php echo e($socio->usuario); ?></td>
                            <td class="filasTable"><?php echo e($socio->nombresSocio); ?></td>
                            <td class="filasTable"><?php echo e($socio->apellidoPaternoSocio.' '.$socio->apellidoMaternoSocio); ?>

                            </td>
                            <td class="filasTable"><?php echo e($socio->dniSocio); ?></td>
                            <td class="filasTable"><?php echo e($socio->departamentoSocio); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
</div>

<script>
$(document).ready(function() {
    $('#example1').DataTable({
        "language": {
            "sProcessing": "Procesando...",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sZeroRecords": "No se encontraron resultados",
            "sEmptyTable": "Ningún dato disponible en esta tabla",
            "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "Buscar:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "<i class='fa fa-angle-right'></i>",
                "sPrevious": "<i class='fa fa-angle-left'></i>"
            },
            "oAria": {
                "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appPartner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>