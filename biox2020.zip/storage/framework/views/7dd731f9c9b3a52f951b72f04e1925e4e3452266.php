<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-12 col-md-12 col-lg-10">

            <div class="card card-secondary mt-3">
                <div class="card-header">
                    Informacion del Producto
                </div>


                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e($producto->urlImagenProducto); ?>" width="170px" height="170px"
                                class="img-fluid rounded">
                        </div>
                        <div class="col-lg-8">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Nombre Producto</label>
                                        <input type="text" value="<?php echo e($producto->nombreProducto); ?>"
                                            class="form-control inputCentrado" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Descripcion</label>
                                        <textarea rows="2" class="form-control inputCentrado"
                                            readonly><?php echo e($producto->descripcionProducto); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Codigo</label>
                                        <input type="text" value="<?php echo e($producto->codigoProducto); ?>"
                                            class="form-control form-control-sm inputCentrado" readonly>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Tipo Unidad</label>
                                        <input type="text" value="<?php echo e($producto->tipoUnidadProducto); ?>"
                                            class="form-control form-control-sm inputCentrado" readonly>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Categoria</label>
                                        <input type="text" value="<?php echo e($producto->categoriaProducto); ?>"
                                            class="form-control form-control-sm inputCentrado" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-9">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Precio</label>
                                        <input type="text" value="<?php echo e($producto->precioProducto); ?>"
                                            class="form-control form-control-sm inputCentrado" readonly>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <table class="table table-striped table-bordered table-sm">
                                        <thead style="background-color:#C184FF">
                                            <tr>
                                                <th class="filasTable">Almacen</th>
                                                <th class="filasTable">Tipo Almacen</th>
                                                <th class="filasTable">Stock</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="filasTable"><?php echo e($stock->nombreAlmacen); ?></td>
                                                <td class="filasTable"><?php echo e($stock->tipoAlmacen); ?></td>
                                                <td class="filasTable"><?php echo e($stock->cantidadStock); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="card-footer">
                    <div class="container-fluid">
                        <div class="row justify-content-between">
                            <div class="col-5 col-sm-5 col-md-5 col-lg-4">
                            </div>
                            <div class="col-5 col-sm-5 col-md-5 col-lg-4">
                                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-danger btn-block btn-sm">
                                    <i class="fas fa-undo-alt"></i> Atras
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>