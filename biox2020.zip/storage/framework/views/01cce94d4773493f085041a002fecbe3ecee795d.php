<?php $__env->startSection('contenido-header'); ?>
<div class="content-header">
    <div class="container">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h1>Perfil</h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-3">
            <div class="card card-widget widget-user">
                <!-- Add the bg color to the header using any of the bg-* classes -->
                <div class="widget-user-header text-white"
                    style="background: url('/adminlte/dist/img/photo1.png') center 68%;">
                </div>
                <div class="widget-user-image">
                    <img class="img-circle" src="/adminlte/dist/img/user3-128x128.jpg" alt="User Avatar">
                </div>
                <div class="mt-5">
                    <h5 class="text-center">Rene Edgard Lozano Ramos</h5>
                    <h6 class="text-center text-secondary">Rango: Heraldo</h6>
                    <h6 class="text-center text-secondary">Codigo: 3423N34</h6>
                </div>
                <div class="card-footer pt-3">
                    <a href="<?php echo e(route('partner.partners.index')); ?>" class="btn bg-gradient-danger btn-xs btn-block">
                        <i class="fas fa-arrow-left"></i> Atras
                    </a>
                </div>
            </div>

        </div>
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="tab-general" data-toggle="pill" href="#content-general"
                                role="tab" aria-controls="content-general" aria-selected="true">General</a>
                        </li>
                    </ul>

                    <div class="tab-content" id="custom-content-below-tabContent">
                        <div class="tab-pane fade show active" id="content-general" role="tabpanel"
                            aria-labelledby="tab-general">
                            <br>
                            <div class="row">
                                <div class="col-lg-6">
                                    <h6>Informacion</h6>
                                    <ul>
                                        <li class="li-sin-signo"><i class="fas fa-phone"></i> 978112323</li>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-envelope"></i>
                                            rene.lozano@tecsup.edu.pe
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-6">
                                    <h6>Colocacion</h6>
                                    <ul>
                                        <li class="li-sin-signo">Patrocinador:
                                            <span class="text-blue" style="text-transform: uppercase">
                                                Jose Edgrad Lozano
                                                Cueva
                                            </span>
                                        </li>
                                        <li class="li-sin-signo">Fecha de Inscripcion: <b>10/12/2001</b></li>
                                    </ul>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-lg-6">
                                    <h6>Direccion</h6>
                                    <ul>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-home"></i> av hunter - tahuatisuyo argentina 123 mz 12
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-6">
                                    <h6>Acciones</h6>
                                    <ul>
                                        <li class="li-sin-signo">
                                            <i class="fas fa-sitemap"></i>
                                            <a href="#">Ver gráfica de linea
                                                descendiente</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appPartner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>