<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-12 col-md-10 col-lg-7">

            <div class="card card-secondary mt-3">
                <div class="card-header">
                    Nuevo Almacen
                </div>

                <form action="<?php echo e(route('admin.warehouses.update')); ?>" method="POST">

                    <?php echo e(csrf_field()); ?>


                    <input type="hidden" value="<?php echo e($almacen->id); ?>" name="id_almacen">

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>Nombre Almacen</label>
                                    <input type="text" name="nombre"
                                        class="form-control form-control-sm inputCentrado<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>"
                                        value="<?php echo e($almacen->nombreAlmacen); ?>">
                                    <?php echo $errors->first('nombre','<span
                                        class="error invalid-feedback">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label>Tipo Almacen</label>
                                    <select name="tipo"
                                        class="form-control form-control-sm<?php echo e($errors->has('tipo') ? ' is-invalid' : ''); ?>">
                                        <?php $__currentLoopData = $tipos_almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($tipo_almacen == $almacen->tipoAlmacen): ?>
                                        <option value="<?php echo e($tipo_almacen); ?>" selected><?php echo e($tipo_almacen); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($tipo_almacen); ?>"><?php echo e($tipo_almacen); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('tipo','<span class="error invalid-feedback">:message</span>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Dirección</label>
                            <textarea name="direccion" rows="2"
                                class="form-control form-control-sm inputCentrado<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>"><?php echo e($almacen->direccionAlmacen); ?></textarea>
                            <?php echo $errors->first('direccion','<span class="error invalid-feedback">:message</span>'); ?>

                        </div>

                    </div>

                    <div class="card-footer">
                        <div class="container-fluid">
                            <div class="row justify-content-between">
                                <div class="col-5 col-sm-5 col-md-5 col-lg-4">
                                    <button type="submit" class="btn btn-primary btn-block btn-sm">
                                        <i class="fas fa-save"></i> Guardar
                                    </button>
                                </div>
                                <div class="col-5 col-sm-5 col-md-5 col-lg-4">
                                    <a href="<?php echo e(route('admin.warehouses.index')); ?>"
                                        class="btn btn-danger btn-block btn-sm">
                                        <i class="fas fa-undo-alt"></i> Atras
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>