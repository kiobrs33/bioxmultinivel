<?php $__env->startSection('contenido-header'); ?>
<div class="content-header">
    <div class="container">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h1>Ordenes o Pedidos</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <h1>Hola</h1>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appEmployee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>