<?php $__env->startSection('contenido-header'); ?>
<div class="content-header">
    <div class="container">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h1>Arból de Socios </h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-header">
                    <div class="row container-fluid">
                        <div class="col-lg-3">
                            <a href="<?php echo e(route('partner.inscriptions.tree-partners',Auth()->user()->Socio->slugSocio)); ?>"
                                class="btn btn-info btn-xs btn-block">
                                <i class="fas fa-tree"></i> Regresar al comienzo
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body" style="height:410px; overflow-y:scroll;">
                    <?php $__currentLoopData = $misSocios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position=>$valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- ACCIENDO A LA INFORMACION DEL LIDER -->
                    <?php if($position == 0): ?>
                    <!-- Con esta condicion controlamos cuando el USARIO MOSTRADO EN EL ARBOL ES EL LOGUEADO  -->
                    <!-- En el caso no lo sea APARECERA UN BOTON para subir de nivel en el arbol -->
                    <?php if(!isset($misSocios[0][0]->slug_lider)): ?>
                    <div class="row justify-content-center">
                        <div class="col-auto">
                            <div class="card card-primary card-outline">
                                <div class="card-body">
                                    <h6 align="center" class="text-sm">Codigo :
                                        <b><?php echo e($misSocios[0][0]->username); ?></b>
                                    </h6>
                                    <div class="row justify-content-center">
                                        <div class="col-auto">
                                            <img class="profile-user-img img-fluid img-circle img-md"
                                                src="/images/imagenVacia.png" alt="User profile picture">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <h6 align="center" class="text-sm">
                                                <?php echo e($misSocios[0][0]->nombresSocio.' '.$misSocios[0][0]->apellidoPaternoSocio.' '.$misSocios[0][0]->apellidoMaternoSocio); ?>

                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="row justify-content-center">
                        <div class="col-auto">
                            <div class="card card-primary card-outline">
                                <div class="card-body">
                                    <div class="row justify-content-center">
                                        <div class="col-12">
                                            <a href="<?php echo e(route('partner.inscriptions.tree-partners',$misSocios[0][0]->slug_lider)); ?>"
                                                class="btn btn-info btn-xs btn-block">
                                                <i class="fas fa-arrow-up"></i> Subir
                                            </a>
                                        </div>
                                    </div>
                                    <h6 align="center" class="text-sm mt-1">Codigo :
                                        <b><?php echo e($misSocios[0][0]->username); ?></b>
                                    </h6>
                                    <div class="row justify-content-center">
                                        <div class="col-auto">
                                            <img class="profile-user-img img-fluid img-circle img-md"
                                                src="/images/imagenVacia.png" alt="User profile picture">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <h6 align="center" class="text-sm">
                                                <?php echo e($misSocios[0][0]->nombresSocio.' '.$misSocios[0][0]->apellidoPaternoSocio.' '.$misSocios[0][0]->apellidoMaternoSocio); ?>

                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php else: ?>
                    <div class="row">
                        <!-- ENLISTADO LOS SOCIOS DIRECTOS -->
                        <?php $__currentLoopData = $misSocios[$position]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-2">
                            <div class="card card-secondary card-outline">
                                <div class="card-body">
                                    <h6 align="center" class="text-sm"><b><?php echo e($item->username); ?></b></h6>
                                    <div class="row justify-content-center">
                                        <div class="col-auto">
                                            <img class="profile-user-img img-fluid img-circle img-md"
                                                src="/images/imagenVacia.png" alt="User profile picture">
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <h6 align="center" class="text-xs">
                                                <?php echo e($item->nombresSocio); ?>

                                            </h6>
                                        </div>
                                    </div>

                                    <div class="row justify-content-center">
                                        <div class="col-12">
                                            <a href="<?php echo e(route('partner.inscriptions.tree-partners',$item->slugSocio)); ?>"
                                                class="btn btn-success btn-xs btn-block">
                                                <i class="fas fa-eye"></i> Ver Arbol
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card card-secondary">
                <div class="card-header">
                    <span>Informacion Extra!</span>
                </div>
                <div class="card-body">
                    <p>1. Aqui se muestra en forma de arbol la organizacion del Socio Logueado</p>
                    <p>2. Para poder observar los socios directos de cada usuario de su organizacion presione el boton
                        de <b>Ver Arbol</b>
                    </p>
                    <p>3. Solo tendra un vista breve de todos los usuarios de su organizacion, no se podra editar o ver
                        informacion privada de sus usuario.</p>
                    <p>Gracias por su atencion</p>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
$(document).ready(function() {
    $('#example1').DataTable({
        "language": {
            "sProcessing": "Procesando...",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sZeroRecords": "No se encontraron resultados",
            "sEmptyTable": "Ningún dato disponible en esta tabla",
            "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "Buscar:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "<i class='fa fa-angle-right'></i>",
                "sPrevious": "<i class='fa fa-angle-left'></i>"
            },
            "oAria": {
                "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appPartner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>