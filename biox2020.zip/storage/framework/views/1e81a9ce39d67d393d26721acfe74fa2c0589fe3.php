<a href="<?php echo e(route('partner.inscriptions.show', $slugSocio)); ?>" class="btn bg-gradient-success btn-xs">
    <i class="fas fa-eye"></i>
</a>