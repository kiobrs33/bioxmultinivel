<?php $__env->startSection('contenidoSocio'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="text-lightblue mb-4"><i class="fas fa-user-alt"></i> Informacion personal</h4>
        <div class="row">
            <div class="col-sm-6 invoice-col">
                <b>Nombres :</b> <?php echo e($socio->nombresSocio); ?><br>
                <b>Apellido Paterno :</b> <?php echo e($socio->apellidoPaternoSocio); ?><br>
                <b>Apellido Materno :</b> <?php echo e($socio->apellidoMaternoSocio); ?>

            </div>
            <div class="col-sm-6 invoice-col">
                <b>Fecha nacimiento :</b> <?php echo e($socio->fechaNacimientoSocio); ?><br>
                <b>Sexo :</b> <?php echo e($socio->sexoSocio); ?><br>
                <b>Dni :</b> <?php echo e($socio->dniSocio); ?>

            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6 invoice-col">
                <b>Direccion :</b> <?php echo e($socio->direccionSocio); ?><br>
                <b>Pais :</b> <?php echo e($socio->paisSocio); ?>

            </div>
            <div class="col-sm-6 invoice-col">
                <b>Departamento :</b> <?php echo e($socio->departamentoSocio); ?><br>
                <b>Provincia :</b> <?php echo e($socio->provinciaSocio); ?><br>
                <b>Distrito :</b> <?php echo e($socio->distritoSocio); ?>

            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6 invoice-col">
                <b>Correo :</b> <?php echo e($socio->correoSocio); ?><br>
                <b>Telefono :</b> <?php echo e($socio->telefonoSocio); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partnerviews.partners.showContainer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>